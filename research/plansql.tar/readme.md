# Research Directory

このディレクトリでは、morpheme-funcs拡張機能の形態素ベースの類似度計算機能について、実装方法とパフォーマンスを比較検証しています。

## 拡張機能の主な特徴

### シンプルな類似度計算
- `calculate_morpheme_score(text, text)`関数一つで形態素ベースの類似度が計算可能
- 実装例: `SELECT calculate_morpheme_score('商品A', '商品B')`

## パフォーマンス検証

### 検証内容
- `extension.sql`: 拡張機能による直接的な類似度計算
  - `calculate_morpheme_score`関数を使用した素直な実装
- `pure_sql.sql`: SQLで同等の機能を実装した場合
  - 形態素解析は他の拡張機能（例：`mecab_dict`）でも実現可能ですが、この検証では自作の`to_morpheme_array`関数を使用

### 高速化の検討
形態素解析結果をテーブルに持たせることで、類似度計算の負荷を軽減できます：
```sql
-- 形態素配列カラムとGINインデックスを活用した例
SELECT id, name, calculate_morpheme_score(name, '検索語') as score
FROM products
WHERE morphemes && to_morpheme_array('検索語')
ORDER BY score DESC;
```


| ケース                           | 概要                                              | 推奨手法具体例          | 速度        | データ容量   | メリット                          | デメリット                        |
|----------------------------------|-------------------------------------------------|-----------------------|------------|-------------|----------------------------------|-----------------------------------|
| 形態素解析済みデータが利用可能(morpheme_scoreなし)   | 事前に形態素解析結果をテーブルに格納し、to_morpheme_arrayを用いて割合を算出する手法。ginインデックスを利用。 | pureQueryUsingMorColumn | 高速       | 大きい      | 事前計算により計算負荷を軽減        | データを用意する必要がある。また、インデックスを保持するため更新時のコストが大きい                   |
| リアルタイム形態素解析(morpheme_scoreあり)  | morpheme_scoreで生データ同士を比較する手法           | calcPureSqlOrder       | 高速(上よりは遅い)       | 中程度       | 実装がシンプル         | インデックスを活用できないため遅い           |
| リアルタイム形態素解析(morpheme_scoreなし)  | to_morpheme_arrayで生データ同士を比較する手法       | pureQuery              | 低速       | 大きい       | textsearch_jaなどによる従来の形態素解析機能のみで実現可能                   | 実装が複雑なわりに速くない。           |

```
psql -d morpheme_funcs -f extension.sql -p 28813 --host /home/vscode/.pgrx
```